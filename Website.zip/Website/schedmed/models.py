from functools import total_ordering
from django.db.models import *
from django.db import models

# Create your models here.

class SchedModel(models.Model):
    x = FloatField(max_length=69)
    y = FloatField(max_length=69)
    deliveryname = CharField(max_length=69, null=True)
    medicine = CharField(max_length=69)
    time = TimeField(null=True)

    class Meta:
        db_table = "Schedule"
