from schedmed.models import SchedModel
from django.forms import *
from signup.models import LoginModel
from django.shortcuts import render
from django import forms

class SchedForm(forms.Form):
    global x, y, name, medicine
    x = FloatField(label="Enter x coordinate")
    y = FloatField(label = "Enter y coordinate")
    deliveryname = CharField(label = "Delivery Name")
    medicine = CharField(label = "Name of medicine")

    class Meta:
        model = SchedModel
        fields = ('x', 'y', 'deliveryname', 'medicine', 'time')

