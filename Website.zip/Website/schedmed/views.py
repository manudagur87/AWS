from schedmed.models import *
from django import forms
from django.http import HttpResponseRedirect, request
from django.shortcuts import render
from django.urls import reverse
from datetime import date, datetime
from schedmed.forms import *

# Create your views here.

def schedmed(request):
    errors = list()
    if request.method == "POST":
        x = request.POST["x"]
        y = request.POST["y"]
        deliveryname = request.POST["deliveryname"]
        medicine = request.POST["medicine"]
        now = datetime.now()
        currtime = now.strftime("%H:%M:%S") 

        data1 = SchedModel(x=x, y=y, deliveryname=deliveryname, medicine=medicine, time = currtime)
        data1.save()
        students = SchedModel.objects.all()
        return render(request, "schedmed.html", {
            "x":x,
            "y":y,
            "deliveryname":deliveryname,
            "medicine":medicine,
            "students" : students
        })
    else:
        schedmedform = SchedForm()
    return render(request, "schedmed.html", {'errors':errors})