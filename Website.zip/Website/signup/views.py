from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.template import context
from signup.models import *
from signup.forms import *
from signup.classes import *
from datetime import date, datetime
from django.template.context import RequestContext

# Create your views here.

def login(request):
    username = "not logged in"
    errors = []
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        verify_data = verify(username,password)
        verify_data.r_username()
        verify_data.r_password()
        errors = verify_data.r_errors()
        try:
            dbuser = LoginModel.objects.get(username = username)
            if password != dbuser.password:
                return render(request,template_name="login.html", context={'errors':['Incorrect Password!']})
        except:
            return render(request,template_name="login.html", context={'errors':["Username does not Exist!"]})

        loginform = LoginForm(request.POST)        
        if loginform.is_valid():
            #information = loginform.cleaned_info()
            #username = information['username']
            if errors == []:
                name = dbuser.name
                username = dbuser.username
                return render(request, "home.html",{"name":name, 'username':username})
    else:
        loginform = LoginForm() 
    return render(request, "login.html", {'errors':errors})

def signup(request):
    errors = list()
    if request.method == "POST":
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        password = request.POST['password']
        confirmpassword = request.POST['confirmpassword']
        email = request.POST['email']
        
        name = first_name + last_name

        data = LoginModel(password = password, name = name, email = email)
        data.save() 
        return render(request, "home.html")
    else:
        signupform = SignupForm()
    return render(request, "signup.html", {'errors':errors}) 

def home(request):
    return render(request, "home.html")

def contact(request):
     errors = list()
     if request.method == "POST":
        firstname = request.POST["firstname"]
        lastname = request.POST["lastname"]
        email = request.POST["email"]
        message = request.POST["subject"]
        Subject = request.POST["Subject"]

        data1 = ContactModel(email=email, feedback=message)
        data1.save()
        return render(request, "home.html")
     else:
        contactform = ContactForm()
     return render(request, "contact.html", {'errors':errors})

def about(request):
    return render(request, "aboutus.html")

def manctrl(request):
    return redirect("robot_controller.html")

def faq(request):
    return render(request, "faq.html")



