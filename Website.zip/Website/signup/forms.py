from django.forms import *
from signup.models import LoginModel
from django.shortcuts import render
from django import forms

class LoginForm(Form):
    username = CharField(max_length=32)
    password = CharField(max_length=32, widget=PasswordInput)

    '''def cleaned_info(self):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        return {"username":username,"password":password} '''

class SignupForm(forms.ModelForm):
    firstname = CharField(max_length=32)
    lastname = CharField(max_length = 32)
    password = CharField(max_length = 32, widget=PasswordInput)
    confirmpassword = CharField(max_length = 32, widget = PasswordInput)
    email = EmailField()

    class Meta:
        model = LoginModel
        fields = ('password', 'name', 'email')

class ContactForm(forms.Form):
    global firstname, lastname, email, country, subject, Subject

    firstname = CharField(label = "First Name")
    lastname = CharField(label="Last Name")
    email = EmailField()
    country = ChoiceField()
    subject = CharField(label="Message")
    Subject = CharField(label="Subject")