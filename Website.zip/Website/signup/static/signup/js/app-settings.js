
  const region = 'ap-southeast-1';
  const iotendpoint = 'a3611c7i1de58-ats.iot.ap-southeast-1.amazonaws.com';
  const iotclientId = 'deliverychallengeroot-RoboMakerDeliveryChallengeThing-DSFUMQMW0W84'
  const subscribe_topic = "deliverychallengeroot-RoboMakerDeliveryChallengeThing-DSFUMQMW0W84/pub";
  const publish_topic = "deliverychallengeroot-RoboMakerDeliveryChallengeThing-DSFUMQMW0W84/sub";
  const PoolId = 'ap-southeast-1:179139d8-59e4-49e5-8398-39d028b09bf1';
