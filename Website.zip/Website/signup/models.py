from django.db import models
from django.db.models import *

# Create your models here.

class LoginModel(models.Model):
    password = CharField(max_length=32)
    name = CharField(max_length=32)
    email = EmailField(max_length=32, null = True)

    class Meta:
        db_table = "User_Details"

class ContactModel(models.Model):
    email = EmailField(max_length=32, null=True)
    feedback = CharField(max_length=1000)

    class Meta:
        db_table = "Contact"